package sandes_parcial1;

/*
Parcial: 1
Alumno: Sandes Julian Naim
DNI: 46.687.343
Fecha: 24/10/2024
Profesor: Christian Baus
*/

public class Sandes_Parcial1 {

    public static void main(String[] args) {
        
        //Testing
        biblioteca bib = new biblioteca();
        bib.agregarPublicacion(new libro("Harry Potter", 1997, "J.K. Rowling", generoLibro.FICCION));
        bib.agregarPublicacion(new revista("Electronic Gaming Monthly", 1994, 200));
        bib.agregarPublicacion(new ilustracion("Ilustracion #1", 2010, "Ana Juan", 200, 125));
        bib.agregarPublicacion(new revista("Billiken", 2010, 356));
        bib.agregarPublicacion(new libro("El origen de las Especies", 1859, "Charles Darwin", generoLibro.CIENCIA));
        bib.agregarPublicacion(new libro("Historia y cronologia del mundo", 2006, "Isaac Asimov", generoLibro.HISTORIA));
        bib.agregarPublicacion(new ilustracion("Ilustracion #2", 2007, "Rebecca Dautremer", 256, 128));
        
        //Llamado de metodos que imprimiran.
        System.out.println("---------Mostrar Publicaciones-----------");
        bib.mostrarPublicaciones();
        System.out.println("");
        System.out.println("-----------Leer Publicaciones------------");
        bib.leerPublicaciones();
    }
    
}
