package sandes_parcial1;
import java.util.ArrayList;

public class biblioteca {
    private ArrayList<publicacion> publicaciones;
    
    //Constructor
    public biblioteca() {
        this.publicaciones = new ArrayList<>();
    }
    
    //Metodos
    public void agregarPublicacion(publicacion pub){
        
        //Si la publicacion resulta ser null haremos que actue la exception NullPointerException.
        if(pub == null){
            throw new NullPointerException("Publicacion invalida a agregar!");
        }
        else{
            //Si esta misma publicacion existe, usaremos la excepcion mismaPublicacionException.
            if(publicacionExistente(pub)){
                throw new mismaPublicacionException("La publicacion " + pub.toString() + " ya fue agregada!");
            }
            else{
                publicaciones.add(pub);
            }
        }
    }
    
    public void mostrarPublicaciones(){
        for (publicacion p : publicaciones) {
            System.out.println(p.toString());
        }
    }
    
    public void leerPublicaciones(){
        for (publicacion p : publicaciones) {
            
            //Unicamente se notificara de que una publicacion es "No-Legible" si es una instancia de ilustracion.
            if(p instanceof ilustracion){
                System.out.println("La publicacion " + p.getTitulo() + " no es legible.");
            }
            else{
                System.out.println("Leyendo la publicacion '" + p.getTitulo() + "' del " + p.getAnio() + ".");
            }
        }
    }
    
    private boolean publicacionExistente(publicacion p){
        boolean r = false;
        
        for (publicacion p2 : publicaciones) {
            if(p2.getTitulo().equals(p.getTitulo()) && p2.getAnio() == p.getAnio()){
                r = true;
                break;
            }
        }
        
        return r;
    }
}
