package sandes_parcial1;

public class ilustracion extends publicacion {
    private String ilustrador;
    private int ancho;
    private int alto;
    
    //Constructor
    public ilustracion(String titulo, int anio, String ilustrador, int ancho, int alto) {
        super(titulo, anio);
        this.ilustrador = ilustrador;
        this.ancho = ancho;
        this.alto = alto;
    }

    @Override
    public String toString() {
        return "ilustracion{" + "ilustrador=" + ilustrador + ", ancho=" + ancho + ", alto=" + alto + '}';
    }
}
