package sandes_parcial1;

public enum generoLibro {
    FICCION,
    NO_FICCION,
    CIENCIA,
    HISTORIA
}
