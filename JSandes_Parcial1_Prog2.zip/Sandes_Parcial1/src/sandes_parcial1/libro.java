package sandes_parcial1;

public class libro extends publicacion {
    private String autor;
    private generoLibro genero; //Usando el enum generoLibro.
    
    //Constructor
    public libro(String titulo, int anio, String autor, generoLibro genero) {
        super(titulo, anio);
        this.autor = autor;
        this.genero = genero;
    }

    @Override
    public String toString() {
        return "libro{" + "autor=" + autor + ", genero=" + genero + '}';
    }
}
