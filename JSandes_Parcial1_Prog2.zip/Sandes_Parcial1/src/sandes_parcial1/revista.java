package sandes_parcial1;

public class revista extends publicacion {
    private int numeroEdicion;
    
    //Constructor
    public revista(String titulo, int anio, int numeroEdicion) {
        super(titulo, anio);
        this.numeroEdicion = numeroEdicion;
    }

    @Override
    public String toString() {
        return "revista{" + "numeroEdicion=" + numeroEdicion + '}';
    }
}
