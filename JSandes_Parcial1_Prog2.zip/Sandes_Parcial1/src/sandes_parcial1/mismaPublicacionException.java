package sandes_parcial1;

public class mismaPublicacionException extends RuntimeException {
    public mismaPublicacionException(String mes){
        super(mes);
    }
}
