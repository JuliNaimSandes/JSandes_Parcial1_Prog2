package sandes_parcial1;

public abstract class publicacion {
    private String titulo;
    private int anio;
    
    //Constructor
    public publicacion(String titulo, int anio) {
        this.titulo = titulo;
        this.anio = anio;
    }
    
    // Getters
    public String getTitulo() {
        return titulo;
    }

    public int getAnio() {
        return anio;
    }
    
    
}
